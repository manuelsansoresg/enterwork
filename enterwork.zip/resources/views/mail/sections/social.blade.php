
<!-- social & contact -->
<table class="social" width="100%">
    <tr>
        <td>

            <!-- column 1 -->
            <table align="left" class="column">
                <tr>
                    <td>

                        <h5 class="">Conectate con nosotros:</h5>
                        <p class=""><a href="#" class="soc-btn fb">Facebook</a> <a href="#" class="soc-btn tw">Twitter</a> <a href="#" class="soc-btn gp">Google+</a></p>


                    </td>
                </tr>
            </table><!-- /column 1 -->

            <!-- column 2 -->
            <table align="left" class="column">
                <tr>
                    <td>

                        <h5 class="">Información de contacto:</h5>
                        <p>Phone: <strong>408.341.0600</strong><br/>
                            Email: <strong><a href="emailto:hseldon@trantor.com">hseldon@trantor.com</a></strong></p>

                    </td>
                </tr>
            </table><!-- /column 2 -->

            <span class="clear"></span>

        </td>
    </tr>
</table><!-- /social & contact -->