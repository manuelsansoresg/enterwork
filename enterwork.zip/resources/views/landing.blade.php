@extends('layouts.default')

@section('content')
<div class="landing">

    <div class="landing__hero">

    </div>
    {{--seccion1--}}
    <div class="container">
        <div class="row">
            <div class="col-12 landing__hero__box">
                <div class="landing__hero__box-content">
                    <p>Somos espacios de trabajo que miran hacia el futuro y a la vez hacia el conjunto diverso de la vida. Porque no hay trabajo sin todo lo demás, ni todo lo demás sin un gran trabajo.</p>
                </div>
            </div>
        </div>
    </div>
    {{--seccion1--}}
    {{--seccion2--}}
    <div class="landing__section2">
        <div class="container">
            <div class="row mt-5">
                <div class="col-12 col-md-8 offset-md-1">
                    <p class="title">Enter_ your new office. </p>
                    <p>
                        Enter_work te ofrece mucho más que un escritorio o una oficina, nuestros espacios de trabajo son flexibles y modernos, con amenidades y servicios especialmente diseñados para ayudarte a concentrarte, colaborar, aprender, socializar y prosperar.
                    </p>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-12 col-md-11 offset-md-1">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-12 col-md-2 text-center">
                                @include('lading_svg.Espacios_Coworking')
                                <p class="">Espacios Coworking</p>
                            </div>
                            <div class="col-12 col-md-2 text-center">
                                @include('lading_svg.Oficinas_Privadas')
                                <p>Oficinas <span class="d-md-block"></span> Privadas</p>
                            </div>

                            <div class="col-12 col-md-2 text-center">
                                @include('lading_svg.Salas_juntas')
                                <p>Salas de <span class="d-md-block"></span>Juntas</p>
                            </div>
                            <div class="col-12 col-md-2 text-center">
                                @include('lading_svg.Coffe_Bar')
                                <p> Coffee<span class="d-md-block"></span> Bar </p>
                            </div>
                            <div class="col-12 col-md-2 text-center">
                                @include('lading_svg.Roof_Terrance')
                                <p>Roof<span class="d-md-block"></span> Terrace</p>
                            </div>
                            <div class="col-12 col-md-2 text-center">
                                @include('lading_svg.Espacios_virtuales')
                                    <p>Espacios<span class="d-md-block"></span> Virtuales </p>
                            </div>
                        </div>
                    </div>



                </div>
            </div>

            <div class="row mt-5">
                <div class="col-12 col-md-11 offset-md-1">
                    <p>Cuando te conviertes en un miembro de Enter_work, no solo has encontrado un nuevo espacio de trabajo, ¡tu membresía incluye acceso a excelentes comodidades! Estos son solo algunos de los servicios que vienen con todos nuestros planes:
                    </p>
                </div>
            </div>

        </div>
    </div>
    {{--/seccion2--}}

    {{--seccion3--}}
    <div class="landing__section3">
        <div class="container">
            <div class="row mt-5">
                <div class="col-12 col-md-11 offset-md-1">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6 align-self-center text-center">
                               <p class="object-bold landing__section3__title"> 360° life <span class="d-md-block">  at work</p>

                            </div>
                            <div class="col-md-4">
                                <ul class="list-inline">
                                    <li class="list-inline"> @include('arrow') <span class="ml-2"> Roof Terrace </span></li>
                                    <li class="list-inline"> @include('arrow') <span class="ml-2"> Coffee Bar</span>  </li>
                                    <li class="list-inline"> @include('arrow') <span class="ml-2"> Eventos de Networking</span> </li>
                                    <li class="list-inline"> @include('arrow') <span class="ml-2">Pet Friendly </span> </li>
                                    <li class="list-inline"> @include('arrow') <span class="ml-2">Salas de juntas interactivas y flexibles </span> </li>
                                    <li class="list-inline"> @include('arrow') <span class="ml-2">Acceso y CCTV 24/7 </span> </li>
                                    <li class="list-inline"> @include('arrow') <span class="ml-2">Staff de apoyo </span> </li>
                                    <li class="list-inline"> @include('arrow') <span class="ml-2">Elevador exclusivo para Enter_work </span> </li>
                                    <li class="list-inline"> @include('arrow') <span class="ml-2">  Estacionamiento amplio</span></li>
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    {{--seccon4--}}
    <div class="landing__section4">
        <div class="container">
           <div class="row mt-5">
               <div class="col-1 align-self-center">
                   <img class="landing__section4__img" src="/img/landing/Flecha_Izq.svg" alt="">
               </div>
               <div class="col-10">
                   <img class="img-fluid" src="img/landing/Recepcion.png" alt="">
               </div>
               <div class="col-1 align-self-center">
                   <img class="landing__section4__img" src="/img/landing/Flecha_Der.svg" alt="">
               </div>
           </div>
            <div class="row">
                <div class="col-12 text-center">
                    Recepción
                </div>
            </div>
        </div>
    </div>
    {{--/seccon4--}}
    {{--seccion5--}}
    <div class="landing__section5 pb-5">
        <div class="container">
            <div class="row mt-5">
                <div class="col-12 col-md-11 offset-md-1">
                    <p class="title mt-5">Enter_ a plan.</p>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3">
                    <div class="landing__section5__circle bg-pink">
                        <span>Desk <br> Service</span>
                        <div class="landing__section5__circle-small">
                           <div class="landing__section5__circle-small__title">
                               desde
                               $900
                           </div>
                        </div>
                    </div>
                    <div class="container">
                        <div class="row mt-4">
                            <div class="col-12">
                               <div class="landing__section5__circle__description">
                                   Recepción de correspondencia<br>
                                   Contestación personalizada<br>
                                   Staff de apoyo<br>
                                   CCTV 24/7<br>
                                   Print Center
                               </div>

                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col-12 text-center">
                                <a href="" class="btn btn-primary">Contratar</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="landing__section5__circle bg-pink2">
                        <span>Meeting  <br> Rooms</span>
                        <div class="landing__section5__circle-small">
                            <div class="landing__section5__circle-small__title">
                                desde
                                $200
                            </div>
                        </div>
                    </div>
                    <div class="container">
                        <div class="row mt-4">
                            <div class="col-12">
                                <div class="landing__section5__circle__description">
                                    Adaptables a tus necesidades <br>
                                    Mobiliario ergonómico<br>
                                    Servicio de café y bebidas<br>
                                    Internet de alta velocidad<br>

                                </div>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col-12 text-center">
                                <a href="" class="btn btn-info">Reservar</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="landing__section5__circle bg-yellow">
                        <span>Coworking </span>
                        <div class="landing__section5__circle-small">
                            <div class="landing__section5__circle-small__title">
                                desde
                                $2,000
                            </div>
                        </div>
                    </div>
                    <div class="container">
                        <div class="row mt-4">
                            <div class="col-12">
                                <div class="landing__section5__circle__description">
                                    Desk Service más: <br>
                                    Acceso ilimitado a espacios <br>
                                    Mobiliario ergonómico <br>
                                    Servicio de café y bebidas <br>
                                    Internet dedicado
                                </div>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col-12 text-center">
                                <a href="" class="btn btn-warning">Contratar</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="landing__section5__circle bg-green">
                        <span>Private</span>
                        <div class="landing__section5__circle-small">
                            <div class="landing__section5__circle-small__title">
                                desde
                                $8,000
                            </div>
                        </div>
                    </div>
                    <div class="container">
                        <div class="row mt-4">
                            <div class="col-12">
                                <div class="landing__section5__circle__description">
                                    Desk Service más: <br>
                                    Oficina Privada <br>
                                    Mobiliario ergonómico <br>
                                    Servicio de café y bebidas <br>
                                    Internet dedicado
                                </div>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col-12 text-center">
                                <a href="" class="btn btn-success">Contratar</a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    {{--seccion5--}}
</div>
@endsection
