<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body bgcolor="#FFFFFF">
    <?php echo $__env->make('mail.sections.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('mail.sections.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- BODY -->
    <table class="body-wrap">
        <tr>
            <td></td>
            <td class="container" bgcolor="#FFFFFF">

                <div class="content">
                    <table>
                        <tr>
                            <td>
                                <h3>¡Tienes una nueva solicitud!</h3>
                                <h4> <?php echo e($request['nombre']); ?> quiere comunicarse con nosotros.</h4>
                                <p class="lead">Datos del usuario : </p>
                                <p class="callout">
                                    Nombre: <?php echo e($request['nombre']); ?>

                                    <br>
                                    Email: <?php echo e($request['email']); ?>

                                    <br>
                                    Teléfono: <?php echo e($request['email']); ?>

                                    <br>
                                    Empresa: <?php echo e($request['telefono']); ?>

                                    <br>
                                    Mensaje: <?php echo e($request['empresa']); ?>

                                    <br>
                                    Estoy interesado/a en:
                                    <br>
                                    <?php $__currentLoopData = $request['interesado']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <ul>
                                            <li><?php echo e($item); ?></li>
                                        </ul>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </p><!-- /Callout Panel -->
                                <p>
                                    No olvides contactarlo lo antes posible para brindarle la información que necesita.
                                </p>
                                <!-- Callout Panel -->
                            </td>
                        </tr>
                    </table>
                </div><!-- /content -->

            </td>
            <td></td>
        </tr>
    </table><!-- /BODY -->
</body>

</html><?php /**PATH C:\laragon\www\enterwork\resources\views/mail/contactoMail.blade.php ENDPATH**/ ?>