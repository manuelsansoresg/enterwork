<!-- HEADER -->
<table class="head-wrap" style="width: 100%; background-color: #000719">
    <tr>
        <td></td>
        <td class="header container">

            <div class="content">
                <table>
                    <tr>
                        <td style="background-color: black">
                            <img src="<?php echo e(asset('img/Enter_Work.svg')); ?>" width="100" alt="">

                        </td>
                    </tr>
                </table>
            </div>

        </td>
        <td></td>
    </tr>
</table><!-- /HEADER --><?php /**PATH C:\laragon\www\enterwork\resources\views/mail/sections/header.blade.php ENDPATH**/ ?>